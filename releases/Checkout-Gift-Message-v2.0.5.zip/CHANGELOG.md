## v2.0.5

- Fixed saved gift messages missing from invoices and packing slips.
- Added standard print observers without core edits. Existing order messages, configured labels, line breaks, and other observers' output are preserved.

# Change history

## v2.0.4, 2026-09-09

- Hid the field and confirmation review for every checkout submission and page transition.
- Prevented the plugin text from appearing while `checkout_confirmation` processes the order.

## v2.0.3, 2026-09-09

- Placed the One Page Checkout field directly beneath the order comments area.
- Added a compact responsive layout that does not inherit checkout label and legend widths.
- Hid the field as soon as checkout review or order submission begins so it cannot appear on the OPC loading screen.

## v2.0.2, 2026-09-09

- Loaded the checkout field through the storefront observer so encapsulated template fallback works with Bootstrap and other installed templates.

## v2.0.1, 2026-09-09

- Corrected the storefront script filename so Zen Cart loads the gift message field during standard checkout, guest checkout, and One Page Checkout.

## v2.0.0, 2026-09-09

- Rebuilt the 2012 customization as an encapsulated Plugin Manager package.
- Removed the need for core file edits and template replacements.
- Added standard checkout, guest checkout, and One Page Checkout support.
- Added configurable field name, directions, placeholder, enabled status, and maximum entry length.
- Added browser and server length enforcement.
- Added confirmation, order email, and admin order display.
- Added safe migration that preserves legacy order messages.
- Added clean uninstall behavior that preserves saved order records.
- Added PHP 8.0 through 8.5 automated syntax checks.

## v1.1, 2012-10-24

- Initial PRO-Webs release for Zen Cart 1.5.0 and 1.5.1.
